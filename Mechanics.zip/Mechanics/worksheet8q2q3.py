from geom2d.vector import Vector
from geom2d.segment import Segment
from geom2d.point import Point

A = Vector(3,6)
B = Vector(5,8)
C = Vector(9,11)

res_add = A.__add__(B).__add__(C)
print("Vector Addition")
print(f"A{A} + B{B} + C{C} = {res_add}")

print("\nMagnitudes")
print(f"A{A.norm}\nB{B.norm}\n{C.norm}")

#dot product of vectors 
print(f"Dot Product of A and B {Vector.dot(A,B)}")
print(f"Dot Product of A and C {Vector.dot(A,C)}")
print(f"Dot Product of B and C {Vector.dot(B,C)}")

#angle between two vectors 
print(A.angle_value_to(B) * (180/3.14))
print(A.angle_to(B) * (180/3.14))

#projection of one point on other 
print(f"projection of vector A over B is: {A.projection_over(B)}")

S = Point(2,3)
E = Point(4,5)
P = Point(3,4)
seg = Segment(S, E)

print(f"Length of the segment {seg.length}")
closeP = seg.closest_point_to(P)
print(f"Closest point to the segment {seg.closest_point_to(P)}")
distTo = P.distance_to(closeP)
print(f"Distance from P to the closest point to P on the segment {seg.closest_point_to(P)}")
