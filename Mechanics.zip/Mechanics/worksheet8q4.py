from geom2d.vector import Vector
from geom2d.line import Line
from geom2d.point import Point

def find_intersection(a1, b1, c1, a2, b2, c2):
  D = a1 * b2 - a2 * b1

  if D == 0:
      # Lines are parallel or coincident
      return "Lines are parallel or coincident"
  else:
      x = (c1 * b2 - c2 * b1) / D
      y = (a1 * c2 - a2 * c1) / D
      return Point(x, y)

a1, b1, c1 = 1, -1, 0  
a2, b2, c2 = 1, 1, 400

intersection = find_intersection(a1, b1, c1, a2, b2, c2)

# Print the result
if isinstance(intersection, Point):
  print(f"Intersection point: ({intersection.x}, {intersection.y})")
else:
  print(intersection)