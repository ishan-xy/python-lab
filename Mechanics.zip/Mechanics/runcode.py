from geom2d.point import Point

p = Point(1, 2)
q = Point(3, 4)
print(p.distance_to(q))
print(f"addition: {p + q}")

print(f"subtraction: {p - q}")
