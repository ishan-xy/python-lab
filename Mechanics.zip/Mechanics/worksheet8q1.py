#Question1
from geom2d.point import Point
print("Enter Point A:")
inpAx = int(input("x1: "))
inpAy = int(input("y1: "))
print("Enter Point B:")
inpBx = int(input("x2: "))
inpBy = int(input("y2: "))

A = Point(inpAx, inpAy)
B = Point(inpBx, inpBy)
print(f"Distance between A{A} and B{B} is {A.distance_to(B)}")

midpoint = A.midpoint(B)
print(f"Midpoint of A{A} and B{B} is {midpoint}")

slope,intercept = A.line(B)
print(f"Equation of line passing through A{A} and B{B} is y = {slope}x + {intercept}")

# Reflection of Point
print("\nEnter point C")
inpCx = int(input("x3: "))
inpCy = int(input("y3: "))

C = Point(inpCx, inpCy)
C_ref = C.reflection(slope, intercept)
print(f"Reflection of {C} against y = {slope}x + {intercept} is {C_ref}")